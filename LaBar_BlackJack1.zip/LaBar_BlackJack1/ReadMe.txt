Blackjack Game

Built w/ .Net 4.6.1 on Visual Studio 2017
Uses MVVM pattern
To do:
Add converter for Bitmap to BitmapImage
Add audio service � remove System.Sounds add System.Media
Add error message service
Improve graphics
Add xaml for button styles
Add Test service - project
 
To do: Game features
Allow player to split
Allow player to double down
Allow player to purchase insurance
Allow for multiple bet (chips) increments


