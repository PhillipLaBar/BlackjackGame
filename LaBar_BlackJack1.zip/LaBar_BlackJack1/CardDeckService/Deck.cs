﻿// Deck.cs 
// Represents a deck of cards (52)
//
// 3/3/2019 initial creation - PJL

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Media.Imaging;
using System.IO;
using System.Drawing.Imaging;

namespace CardDeckService
{
    public class Deck
    {
        private List<Card> _cards = new List<Card>();
        private BitmapImage _cardBack;

        /// <summary>
        /// Height and Width of deck
        /// </summary>
        public readonly int _height = 97;
        public readonly int _width = 73;

        /// <summary>
        /// Card image spacing
        /// </summary>
        int cardSuitSpace = 98;
        int cardFaceSpace = 73;

        public Deck()
        {
            InitNewDeck();
        }
      
        /// <summary>
        ///  Create 52 cards and add them to the Cards List
        /// </summary>
        private void InitNewDeck()
        {
            try
            {
                _cards.Clear();

                Bitmap fullDeckImage = Properties.Resource1.Cards;

                foreach (Suit cardSuit in Enum.GetValues(typeof(Suit)))
                {
                    foreach (Face cardFace in Enum.GetValues(typeof(Face)))
                    {
                        Card playingCard = new Card();
                        playingCard.Image = GetCardImage(fullDeckImage, (int)cardFace, (int)cardSuit);

                        playingCard.CardSuit = cardSuit;
                        playingCard.CardFace = cardFace;

                        _cards.Add(playingCard);
                    }
                }

                Bitmap tempCardBack = Properties.Resource1.CardBack;
                CardBack = GetCardImage(tempCardBack, 0, 0);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BitmapImage GetCardImage(Bitmap deckImage, int face, int suit)
        {
            try
            {
                Bitmap cardImg = new Bitmap(_width, _height);
                Graphics g = Graphics.FromImage(cardImg);
                g.DrawImage(deckImage, new Rectangle(0, 0, _width, _height),
                            new Rectangle(cardFaceSpace * face, cardSuitSpace * suit, _width, _height), GraphicsUnit.Pixel);
                g.Dispose();

                // verify - write bitmap out to file
                //cardImg.Save(face.ToString() + "_" + suit.ToString() + ".png");

                // Need to convert to BitmapImage for WPF binding
                BitmapImage retImage = GetBitMapImageFromBitMap(cardImg);
                return retImage;
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        private BitmapImage GetBitMapImageFromBitMap(Bitmap bitmap)
        {
            try
            {
                MemoryStream ms = new MemoryStream();
                bitmap.Save(ms, ImageFormat.Png);
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                ms.Seek(0, SeekOrigin.Begin);
                image.StreamSource = ms;
                image.EndInit();
                return image;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public List<Card> Cards
        {
            get { return _cards; }
            set { _cards = value; }
        }

        public BitmapImage CardBack
        {
            get { return _cardBack; }
            set { _cardBack = value; }
        }

    }
}
