﻿// Enums.cs 
// Code file to hold enums for the Card Service
//
// 3/3/2019 initial creation - PJL


namespace CardDeckService
{
    /// <summary>
    /// Locked to the oder of reading in bitmap, future work decouple
    /// </summary>
    public enum Face
    {
        Ace,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King,
    };

    /// <summary>
    /// Locked to the oder of reading in bitmap, future work decouple
    /// </summary>
    public enum Suit
    {
        Club,
        Spade,
        Heart,
        Diamond
    };


}