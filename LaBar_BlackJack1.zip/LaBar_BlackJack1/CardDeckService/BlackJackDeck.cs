﻿// Deck.cs 
// Represents a deck of cards for the game of BlackJack (52)
//
// 3/3/2019 initial creation - PJL


namespace CardDeckService
{
    public class BlackJackDeck : Deck
    {
        private int _aceSecondValue = 11;

        public BlackJackDeck()
        {
            InitBlackJackDeckValues();
        }

        private void InitBlackJackDeckValues()
        {
            foreach(Card c in Cards)
            {
                switch (c.CardFace)
                {
                    case Face.Ace:
                        c.CardValue = 1;
                        break;
                    case Face.Two:
                        c.CardValue = 2;
                        break;
                    case Face.Three:
                        c.CardValue = 3;
                        break;
                    case Face.Four:
                        c.CardValue = 4;
                        break;
                    case Face.Five:
                        c.CardValue = 5;
                        break;
                    case Face.Six:
                        c.CardValue = 6;
                        break;
                    case Face.Seven:
                        c.CardValue = 7;
                        break;
                    case Face.Eight:
                        c.CardValue = 8;
                        break;
                    case Face.Nine:
                        c.CardValue = 9;
                        break;
                    default:
                        c.CardValue = 10;
                        break;
                }
            }
        }

        public int AceSecondValue
        {
            get { return _aceSecondValue; }
        }
    }
}
