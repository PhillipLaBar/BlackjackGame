﻿// Card.cs 
// Represents a single playing card
//
// 3/3/2019 initial creation - PJL

using System.Windows.Media.Imaging;

namespace CardDeckService
{
    public class Card
    {
        private int _id = 0;
        private int _cardValue = 0;
        private BitmapImage _image;

        private Face _cardFace;
        private Suit _cardSuit;

        public Card()
        {
            
        }

        public int ID
        {
            get { return _id; }
            set { _id = value;}
        }

        public int CardValue
        {
            get { return _cardValue; }
            set { _cardValue = value; }
        }

        public BitmapImage Image
        {
            get { return _image; }
            set { _image = value; }
        }

        public Face CardFace
        {
            get { return _cardFace; }
            set { _cardFace = value; }
        }

        public Suit CardSuit
        {
            get { return _cardSuit; }
            set { _cardSuit = value; }
        }
    }
}
