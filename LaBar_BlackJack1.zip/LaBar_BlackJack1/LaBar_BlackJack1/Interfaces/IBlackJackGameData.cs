﻿// IBlackHackGameData.cs 
// Used to pass data between datacontext and game VM
//
// 3/3/2019 initial creation - PJL

using CardDeckService;
using LaBar_BlackJack1.Model;
using System.Collections.Generic;
using System.Windows.Media.Imaging;

namespace LaBar_BlackJack1.Interfaces
{
    public interface IBlackJackGameData
    {
        M_BlackJackGame BlackJackGame { get; set; }
        M_HighScores HighScores { get; set; }
        void InitNewGame();
        void UpdatePlayerBet();
        void DealInitialCards();
        void PlayerHit();
        void ProcessDealerTurn();
        void StartNextHand();
        void QuitCurrentGame();
        bool CheckForBlackJack();
        bool CheckForPlayerBust();
        void AddNewHighScores();
        bool PlayerHasChips();
        string GetGameResults();
        List<Card> GetPlayerCardsInHand();
        List<Card> GetDealerCardsInHand();
        int GetPlayerCash();
        int GetPlayerCurrentBet();
        int GetPlayerTotalHandValue();
        int GetDealerTotalHandValue();
        BitmapImage GetDealerDownCardImage();
        BitmapImage GetCardBackImage();
    }
}
