﻿// M_Player.cs 
// Represents a blackjack player
//
// 3/3/2019 initial creation - PJL


using CardDeckService;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LaBar_BlackJack1.Model
{
    public class M_Player : INotifyPropertyChanged
    {
        private M_Hand _playerHand;
        private int _cash;
        private int _currentBet;
        private readonly int  _startingCash = 500;

        // ToDo : add multiple chip values
        private readonly int _betValue = 25;

        public M_Player()
        {
            _playerHand = new M_Hand();
        }

        public M_Hand PlayerHand
        {
            get { return _playerHand; }
            set { _playerHand = value; }
        }

        public int Cash
        {
            get { return _cash; }
            set
            {
                if (_cash != value)
                {
                    _cash = value;
                    OnPropertyChanged();
                }
            }
        }

        public int CurrentBet
        {
            get { return _currentBet; }
            set
            {
                if (_currentBet != value)
                {
                    _currentBet = value;
                    OnPropertyChanged();
                }
            }
        }

        public void SetPlayerStartingCash()
        {
            Cash = _startingCash;
        }

        public void PlaceBet()
        {
            CurrentBet += _betValue;
            Cash -= _betValue;
        } 

        /// <summary>
        /// Add card to player hand
        /// Update Total Value of cards
        /// send player hand property change
        /// </summary>
        /// <param name="card"></param>
        public void AddCardsToHand(Card card)
        {
            _playerHand.AddCard(card);
            OnPropertyChanged("CardsInHand");
            // could use 1 event
            OnPropertyChanged("TotalHandValue");
        }
        
        public bool HasChips()
        {
            return _cash >= _betValue ? true : false;
        }

        public void Push()
        {
             Cash += CurrentBet;
             CurrentBet = 0;
        }

        public void Lose()
        {
           //CurrentBet = 0;
        }       

        public void Win(bool blackJack)
        {
            if(blackJack)
            {
                Cash += CurrentBet + (int)(CurrentBet * 1.5f);
                CurrentBet += CurrentBet + (int)(CurrentBet * 1.5f);
            }
            else
            {
                Cash += CurrentBet * 2;
            }
        }

        public void DiscardHand()
        {
            _playerHand.CardsInHand.Clear();
            _playerHand.TotalHandValue = 0;
            OnPropertyChanged("CardsInHand");
            // could use 1 event
            OnPropertyChanged("TotalHandValue");
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
