﻿// M_HighScores.cs 
// Will load and update user highscores
//
// 3/3/2019 initial creation - PJL

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace LaBar_BlackJack1.Model
{
    public class M_HighScores : INotifyPropertyChanged
    {
        private List<int> _highScores = new List<int>();

        public M_HighScores()
        {
            ReadHighScores();
            OnPropertyChanged();
        }

        public List<int> HighScores
        {
            get { return _highScores; }
            set { _highScores = value;}
        }

        public void AddNewHighScore(int score)
        {           
            _highScores.Add(score);
            _highScores.Sort();
            if (_highScores.Count > 9)
                _highScores = _highScores.GetRange(0, 10);
            _highScores.Reverse();
            OnPropertyChanged();
            SaveHighScores();
        }              
        
        private void ReadHighScores()
        {
            try
            {
                // Read the XML that contains highscores 
                var filename = "HighScores.xml";
                var currentDirectory = Directory.GetCurrentDirectory();
                var purchaseOrderFilepath = Path.Combine(currentDirectory, filename);

                XElement purchaseOrder = XElement.Load($"{purchaseOrderFilepath}");

                _highScores =
                     purchaseOrder.Descendants("score").Select(x => (int)x).ToList();
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        public void SaveHighScores()
        {
            XElement xmlElements = new XElement("HighScores", HighScores.Select(i => new XElement("score", i)));
            xmlElements.Save("HighScores.xml");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }   
}
