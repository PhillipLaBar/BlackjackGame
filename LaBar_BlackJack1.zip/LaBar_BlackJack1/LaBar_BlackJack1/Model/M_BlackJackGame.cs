﻿// M_BlackJackGame.cs 
// Represents a blackjack game
//
// 3/3/2019 initial creation - PJL


using System;
using System.Collections.Generic;
using System.ComponentModel;
using CardDeckService;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Media;

namespace LaBar_BlackJack1.Model
{
    public class M_BlackJackGame : INotifyPropertyChanged
    {
        private M_Player _player;
        private M_Dealer _dealer;
        private BlackJackDeck _gameDeck;

        private string _gameResults;

        public M_BlackJackGame()
        {
            try
            { 
                _gameDeck = new BlackJackDeck();
                _player = new M_Player();
                _dealer = new M_Dealer();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error on startup.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }  
        }


        public M_Player Player
        {
            get { return _player; }
            set { _player = value; }
        }

        public M_Dealer Dealer
        {
            get { return _dealer; }
            set { _dealer = value; }
        }

        public BlackJackDeck GameDeck
        {
            get { return _gameDeck; }
            set { _gameDeck = value; }
        }

        public string GameResults
        {
            get { return _gameResults; }
            set
            {
                if (_gameResults != value)
                {
                    _gameResults = value;
                    OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Deal out first 4 cards 
        /// </summary>
        public void OpeningDeal()
        {
            List<Card> cards = DrawRandomCardsFromDeck(4);

            _player.AddCardsToHand(cards[0]);
            _player.AddCardsToHand(cards[1]);
            _dealer.AddDownCard(cards[2]);
            _dealer.AddCardsToHand(cards[3]);          
        }


        public void HitPlayer()
        {
            List<Card> cards = DrawRandomCardsFromDeck(1);
            _player.AddCardsToHand(cards[0]);
        }
       

        /// <summary>
        /// Draw dealer cards until > 16
        /// </summary>
        public void DrawCardsForDealer()
        { 
            while(_dealer.DealerHand.TotalHandValue < GameValues.DealerStandValue)
            {
                List<Card> cards = DrawRandomCardsFromDeck(1);
                _dealer.AddCardsToHand(cards[0]);
            }

            Outcome();
        }

        public void Outcome()
        {
            if(!CheckForDealerBust())
            {
                if(!CheckForTie())
                {
                    if(_player.PlayerHand.TotalHandValue >
                       _dealer.DealerHand.TotalHandValue)
                    {
                        _player.Win(false);
                        SystemSounds.Asterisk.Play();
                        GameResults = "You Win!";
                    }
                    else
                    {
                        _player.Lose();
                        SystemSounds.Hand.Play();
                        GameResults = "Sorry";
                    }                                    
                }
            }
        }
               

        public bool CheckForBlackJack()
        {
            if(_player.PlayerHand.TotalHandValue == GameValues.BustValue &&
               _dealer.DealerHand.TotalHandValue == GameValues.BustValue)
            {
                _player.Push();
                SystemSounds.Beep.Play();
                GameResults = "Push";
                return true;                
            }
            else if (_player.PlayerHand.TotalHandValue == GameValues.BustValue)
            {
                _player.Win(true);
                SystemSounds.Asterisk.Play();
                GameResults = "You Win!";
                return true;
            }
            else if (_dealer.DealerHand.TotalHandValue == GameValues.BustValue)
            {
                _player.Lose();
                SystemSounds.Hand.Play();
                GameResults = "Sorry";
                return true;
            }

            return false;
        }

        public bool CheckForPlayerBust()
        {
            if(_player.PlayerHand.TotalHandValue > GameValues.BustValue)
            {
                _player.Lose();
                SystemSounds.Hand.Play();
                GameResults = "You Busted";
                return true;
            }

            return false;
        }

        public bool CheckForDealerBust()
        {
            if (_dealer.DealerHand.TotalHandValue > GameValues.BustValue)
            {
                _player.Win(false);
                SystemSounds.Asterisk.Play();
                GameResults = "You Win!";
                return true;
            }

            return false;
        }

        public bool CheckForTie()
        {
            if (_dealer.DealerHand.TotalHandValue == _player.PlayerHand.TotalHandValue)
            {
                _player.Push();
                SystemSounds.Beep.Play();
                GameResults = "Push";
                return true;
            }

            return false;
        }

        /// <summary>
        /// Hand is over, reset player, dealer and deck for next round
        /// TBD - May be easier to discard deck and pull new one...
        /// </summary>
        public void HandComplete()
        {
            ResetDeck();
            GameResults = "Current Bet";
            _player.CurrentBet = 0;                    
        }

        public void ResetDeck()
        {
            // put player cards back in deck
            foreach (Card c in _player.PlayerHand.CardsInHand)
            {
                _gameDeck.Cards.Add(c);
            }

            _player.DiscardHand();

            foreach (Card c in _dealer.DealerHand.CardsInHand)
            {
                _gameDeck.Cards.Add(c);
            }

            _gameDeck.Cards.Add(_dealer.DealerHand.DownCard);

            _dealer.DiscardHand();
        }



        /// <summary>
        /// Remove n number of cards from the deck and return them
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public List<Card> DrawRandomCardsFromDeck(int num)
        {
            try
            {
                List<Card> retCards = new List<Card>();
                Random rndNumber = new Random();
                int cardNumber = 0;

                for (int n = 0; n < num; n++)
                {
                    cardNumber = rndNumber.Next(_gameDeck.Cards.Count);
                    retCards.Add(_gameDeck.Cards[cardNumber]);
                    _gameDeck.Cards.RemoveAt(cardNumber);
                }

                return retCards;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error getting cards from deck.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        public void UpdateHighscores()
        {

        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }      
    }   

    static class GameValues
    {
        public static int BustValue = 21;
        public static int DealerStandValue = 17;
    }   
}
