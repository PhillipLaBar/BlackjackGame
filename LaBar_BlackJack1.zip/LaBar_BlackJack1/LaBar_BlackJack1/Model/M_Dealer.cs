﻿// M_Dealer.cs 
// Represents a dealer
//
// 3/3/2019 initial creation - PJL

using CardDeckService;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LaBar_BlackJack1.Model
{
    public class M_Dealer : INotifyPropertyChanged
    {
        private M_DealerHand _dealerHand;

        public M_Dealer()
        {
            _dealerHand = new M_DealerHand();
        }

        public M_DealerHand DealerHand
        {
            get { return _dealerHand; }
            set { _dealerHand = value; }
        }

        public void AddCardsToHand(Card card)
        {
            _dealerHand.AddCard(card);
            OnPropertyChanged("CardsInHand");
        }

        public void AddDownCard(Card card)
        {
            _dealerHand.DownCard = card;
            OnPropertyChanged("DownCardShowBack");
        }

        public void Update()
        {
            OnPropertyChanged("TotalHandValue");
        }

        public void DiscardHand()
        {
            _dealerHand.DownCard = null;
            _dealerHand.CardsInHand.Clear();

            OnPropertyChanged("CardsInHand");
            OnPropertyChanged("DiscardDownCard");
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
