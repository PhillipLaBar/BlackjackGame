﻿// M_DealerHand.cs 
// Represents a dealers hand 
//
// 3/3/2019 initial creation - PJL

using CardDeckService;

namespace LaBar_BlackJack1.Model
{
    public class M_DealerHand : M_Hand
    {
        private Card _downCard;

        public M_DealerHand()
        {
            
        }

        public Card DownCard
        {
            get { return _downCard; }
            set { _downCard = value; }
        }

        public override void UpdateTotalHandValue()
        {
            bool aceFound = false;
            bool downCardAce = false;
            int tempHandValue = 0;

            // Add in dealers down card
            if(DownCard.CardFace == CardDeckService.Face.Ace)
            {
                aceFound = true;
                downCardAce = true;
            }
            else
            {
                tempHandValue = DownCard.CardValue;
            }

            foreach (Card c in CardsInHand)
            {
                if ( (c.CardFace == CardDeckService.Face.Ace) && !aceFound)
                {
                    aceFound = true;
                }
                else
                {
                    tempHandValue += c.CardValue;
                }
            }

            // The 1st ace may be used as 1 or 11 
            if(aceFound || downCardAce)
            {
                // Todo pull 1 and 11 from service
                tempHandValue += (tempHandValue + 11) > GameValues.BustValue ? 1 : 11;
            }

            TotalHandValue = tempHandValue;
        }
    }
}
