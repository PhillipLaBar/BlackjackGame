﻿// M_Hand.cs 
// Represents a signle hand in a game of blackjack 
//
// 3/3/2019 initial creation - PJL

using CardDeckService;
using System.Collections.Generic;

namespace LaBar_BlackJack1.Model
{
    public class M_Hand
    {
        private List<Card> _cardsInHand = new List<Card>();
        private int _totalHandValue;

        public M_Hand()
        {

        }


        public List<Card> CardsInHand
        {
            get { return _cardsInHand; }
            set { _cardsInHand = value; }
        }

        public int TotalHandValue
        {
            get { return _totalHandValue; }
            set { _totalHandValue = value; }
        }


        public void AddCard(Card card)
        {
            _cardsInHand.Add(card);
            UpdateTotalHandValue();
        }

        public virtual void UpdateTotalHandValue()
        {
            bool aceFound = false;
            int tempHandValue = 0;            

            foreach (Card c in CardsInHand)
            {
                // Skip adding 1st ace
                if (c.CardFace == CardDeckService.Face.Ace && !aceFound)
                {
                    aceFound = true;
                }  
                else
                {
                    tempHandValue += c.CardValue;
                }                           
            }

            if(aceFound)
            {
                // Todo pull 1 and 11 from service
                tempHandValue += (tempHandValue + 11) > GameValues.BustValue ? 1 : 11;
            }

            TotalHandValue = tempHandValue;
        }

        public bool AceInHand()
        {
            foreach (Card c in CardsInHand)
            {
                if(c.CardFace == CardDeckService.Face.Ace)
                {
                    return true;
                }  
            }

            return false;
        }       
    }
}
