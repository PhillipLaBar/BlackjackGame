﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaBar_BlackJack1
{
    public enum GameState
    {
        NoGame,
        WaitingInitialBet,
        BetOrDeal,
        HitOrStand,
        DealerTurn,
        NextHand
    }
    
}
