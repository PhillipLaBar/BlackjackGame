﻿// BlackJackGameDataService.cs 
// Used to pass data between datacontext and game VM
//
// 3/3/2019 initial creation - PJL

using System.Collections.Generic;
using System.Windows.Media.Imaging;
using CardDeckService;
using LaBar_BlackJack1.Interfaces;
using LaBar_BlackJack1.Model;

namespace LaBar_BlackJack1.Services
{
    public class BlackJackGameDataService : IBlackJackGameData
    {
        private M_BlackJackGame _blackJackGame = new M_BlackJackGame();
        private M_HighScores _highScroes = new M_HighScores();

        public M_BlackJackGame BlackJackGame
        {
            get { return _blackJackGame; }
            set { _blackJackGame = value; }
        }

        public M_HighScores HighScores
        {
            get { return _highScroes; }
            set { _highScroes = value; }
        }

        public void InitNewGame()
        {
            BlackJackGame.Player.SetPlayerStartingCash();
        }

        public void UpdatePlayerBet()
        {
            BlackJackGame.Player.PlaceBet();
        }
        public void DealInitialCards()
        {
            BlackJackGame.OpeningDeal();
        }
        public void PlayerHit()
        {
            BlackJackGame.HitPlayer();
        }
        public void ProcessDealerTurn()
        {
            BlackJackGame.DrawCardsForDealer();
        }
        public void StartNextHand()
        {
            BlackJackGame.HandComplete();
        }
        public void QuitCurrentGame()
        {   // Do Nothing
        }       

        public bool CheckForBlackJack()
        {
            return BlackJackGame.CheckForBlackJack();
        }

        public bool CheckForPlayerBust()
        {
            return BlackJackGame.CheckForPlayerBust();
        }

        public void AddNewHighScores()
        {
            HighScores.AddNewHighScore(BlackJackGame.Player.Cash);
        }

        public bool PlayerHasChips()
        {
            return BlackJackGame.Player.HasChips();
        }

        public string GetGameResults()
        {
            return BlackJackGame.GameResults;
        }

        public List<Card> GetPlayerCardsInHand()
        {
            return BlackJackGame.Player.PlayerHand.CardsInHand;
        }

        public List<Card> GetDealerCardsInHand()
        {
            return BlackJackGame.Dealer.DealerHand.CardsInHand;
        }

        public int GetPlayerCash()
        {
           return BlackJackGame.Player.Cash;
        }

        public int GetPlayerCurrentBet()
        {
            return BlackJackGame.Player.CurrentBet;
        }

        public int GetPlayerTotalHandValue()
        {
            return BlackJackGame.Player.PlayerHand.TotalHandValue;
        }

        public int GetDealerTotalHandValue()
        {
            return BlackJackGame.Dealer.DealerHand.TotalHandValue;
        }

        public BitmapImage GetDealerDownCardImage()
        {
            return BlackJackGame.Dealer.DealerHand.DownCard.Image;
        }

        public BitmapImage GetCardBackImage()
        {
            return BlackJackGame.GameDeck.CardBack;
        }
    }
}
