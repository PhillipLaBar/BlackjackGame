﻿// Vm_BlackJackViewBindings.cs 
// Collections and Data maintained by the VM to update View
//
// 3/3/2019 initial creation - PJL


using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LaBar_BlackJack1.ViewModel
{
    public partial class VM_BlackJack : INotifyPropertyChanged
    {      

        #region High Score Bindings
        private ObservableCollection<int> _playerHighScores = new ObservableCollection<int>();
        public ObservableCollection<int> PlayerHighScores
        {
            get { return _playerHighScores; }
            set { _playerHighScores = value; }

        }    
        #endregion

        #region Player Current Bet
        private int _currentBet;
        public int CurrentBet
        {
            get { return _currentBet; }
            set {
                    if (_currentBet != value)
                    {
                        _currentBet = value;
                        OnPropertyChanged();
                    }
                }
        }       
        #endregion
               

        #region Player Cash Update
        private int _playerCash;
        public int PlayerCash
        {
            get { return _playerCash; }
            set
            {
                if (_playerCash != value)
                {
                    _playerCash = value;
                    OnPropertyChanged();
                }
            }
        }
        #endregion

        #region Player Total Points
        private int _playerTotalPoints;
        public int PlayerTotalPoints
        {
            get { return _playerTotalPoints; }
            set
            {
                if (_playerTotalPoints != value)
                {
                    _playerTotalPoints = value;
                    OnPropertyChanged();
                }
            }
        }
        #endregion

        #region Dealer Total Points
        private string _dealerTotalPoints;
        public string DealerTotalPoints
        {
            get { return _dealerTotalPoints; }
            set
            {
                if (_dealerTotalPoints != value)
                {
                    _dealerTotalPoints = value;
                    OnPropertyChanged();
                }
            }
        }
        #endregion

        #region HandStatus
        private string _handStatus;
        public string HandStatus
        {
            get { return _handStatus; }
            set
            {
                if (_handStatus != value)
                {
                    _handStatus = value;
                    OnPropertyChanged();
                }
            }
        }
        #endregion

        #region Player Cards Update
        private ObservableCollection<BitmapImage> _playerHandImages = new ObservableCollection<BitmapImage>();
        public ObservableCollection<BitmapImage> PlayerHandImages
        {
            get { return _playerHandImages; }
            set { _playerHandImages = value; }           
        }

       
        #endregion

        #region Dealer Cards Update

        private ObservableCollection<BitmapImage> _dealerHandImages = new ObservableCollection<BitmapImage>();
        public ObservableCollection<BitmapImage> DealerHandImages
        {
            get { return _dealerHandImages; }
            set { _playerHandImages = value; }            
        }

       
        #endregion

        #region Dealer Down Card Updated

        private ObservableCollection<BitmapImage> _dealerHandDownCard = new ObservableCollection<BitmapImage>();
        public ObservableCollection<BitmapImage> DealerHandDownCard
        {
            get { return _dealerHandDownCard; }
            set { _playerHandImages = value; }            
        }
        #endregion

        private BitmapImage _tablePic = new BitmapImage();
        public BitmapImage TablePic
        {
            get { return _tablePic; }
            set { _tablePic = value; }
        }

        private string _rules;
        public string Rules
        {
            get { return _rules; }
            set
            {
                if (_rules != value)
                {
                    _rules = value;
                    OnPropertyChanged();
                }
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }    
    }
}
