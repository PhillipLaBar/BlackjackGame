﻿// M_BlackJack.cs 
// View Model used to update the GUI on Game changes
//
// 3/3/2019 initial creation - PJL
using LaBar_BlackJack1.Model;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.ComponentModel;
using System.IO;
using System.Drawing.Imaging;
using System.Windows;
using System;
using System.Media;
using LaBar_BlackJack1.Services;
using LaBar_BlackJack1.Interfaces;

namespace LaBar_BlackJack1.ViewModel
{
    public partial class VM_BlackJack :INotifyPropertyChanged
    {
        private IBlackJackGameData _bjgDataContext;
      
        private GameState _gameState;       

        public VM_BlackJack(IBlackJackGameData game)
        {
            _bjgDataContext = game;
            LoadGameObjects();

            Bitmap table = Properties.Resources.BlackJackTable;
            TablePic = GetBitMapImageFromBitMap(table);
        }

        public void LoadGameObjects()
        {
            try
            {              
                _gameState = GameState.NoGame;

                InitModelComms();
                InitCommands();
                InitHighScores();

                DealerTotalPoints = "0";
                HandStatus = "Current Bet";
            }
            catch
            {
                MessageBox.Show("Error loading game objects.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitModelComms()
        {
            _bjgDataContext.HighScores.PropertyChanged += HighScores_PropertyChanged;
            _bjgDataContext.BlackJackGame.Player.PropertyChanged += Player_PropertyChanged;
            _bjgDataContext.BlackJackGame.Dealer.PropertyChanged += Dealer_PropertyChanged;
            _bjgDataContext.BlackJackGame.PropertyChanged += Game_PropertyChanged;           
        }

       
        private void InitCommands()
        {
            NextHandCommand = new BlackJackICommand(OnNextHand, CanNextHand);
            PlaceBetCommand = new BlackJackICommand(OnPlaceBet, CanPlaceBet);
            DealCommand = new BlackJackICommand(OnDeal, CanDeal);
            HitCommand = new BlackJackICommand(OnHit, CanHit);
            StandCommand = new BlackJackICommand(OnStand, CanStand);
            NewGameCommand = new BlackJackICommand(OnNewGame, CanNewGame);
            QuitCommand = new BlackJackICommand(OnQuit, CanQuit);
            RulesCommand = new BlackJackICommand(OnRules, CanRules);
        }

        private void InitHighScores()
        {            
            HighScores_PropertyChanged(this, new PropertyChangedEventArgs("HighScores"));
        }    
       
        /// <summary>
        /// When game state is changed, set View control state
        /// </summary>
        public GameState CurrentGameState
        {
            get { return _gameState; }
            set
            {
                if (_gameState != value)
                {
                    _gameState = value;
                    UpdateViewControls();
                }
            }
        }

        private bool _showRules = false;
        public void ShowOrHideRules()
        {  
            if (_showRules)
            {
                Rules = "";
                _showRules = false;
            }
            else
            {
                Rules = "\n\n Table Min $25 \n " +
                        "Multiple bets allowed \n " +
                        "Blackjack pays *1.5 \n " +
                        "Sorry no insurance or splits \n \n \n" +
                        "Always gamble responsibly.  \n" +
                        "National gabling hotline \n" +
                        "    1-800-522-4700\n"; 
                _showRules = true;
            }
        }

        private BitmapImage GetBitMapImageFromBitMap(Bitmap bitmap)
        {
            try
            {
                MemoryStream ms = new MemoryStream();
                bitmap.Save(ms, ImageFormat.Png);
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                ms.Seek(0, SeekOrigin.Begin);
                image.StreamSource = ms;
                image.EndInit();
                return image;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        private void UpdateViewControls()
        {
            NextHandCommand.RaiseCanExecuteChanged();
            NewGameCommand.RaiseCanExecuteChanged();
            PlaceBetCommand.RaiseCanExecuteChanged();
            DealCommand.RaiseCanExecuteChanged();
            HitCommand.RaiseCanExecuteChanged();
            StandCommand.RaiseCanExecuteChanged();
            QuitCommand.RaiseCanExecuteChanged();
        }
    }
}
