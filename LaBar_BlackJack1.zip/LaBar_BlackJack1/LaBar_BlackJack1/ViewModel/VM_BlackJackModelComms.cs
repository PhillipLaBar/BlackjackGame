﻿// VM_BlackJackModelComms.cs 
// Handlers used to update view content when on Model data modifications
//
// 3/3/2019 initial creation - PJL


using CardDeckService;
using System.ComponentModel;

namespace LaBar_BlackJack1.ViewModel
{
    public partial class VM_BlackJack : INotifyPropertyChanged
    {

        #region Model Listeners
        /// <summary>
        /// Update The ObservableCollection 
        /// ToDo: Use Custom EventArg to pass data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HighScores_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //Update binding from model
            PlayerHighScores.Clear();
            foreach (int i in _bjgDataContext.HighScores.HighScores)
            {
                PlayerHighScores.Add(i);
            }
        }

        /// <summary>
        /// Update The ObservableCollection 
        /// ToDo: Use Custom EventArg to pass data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Game_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //Update binding from model
            switch (e.PropertyName)
            {
                case "GameResults":
                    GameResultsUpdated();
                    break;                
            }
        }

        /// <summary>
        /// Update property binding 
        /// ToDo: Use Custom EventArg to pass data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Player_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "CardsInHand":
                    PlayerCardsInHandChanged();
                    break;
                case "Cash":
                    PlayerCashChanged();
                    break;
                case "CurrentBet":
                    PlayerCurrentBetChanged();
                    break;
                case "TotalHandValue":
                    PlayerTotalHandValueChanged();
                    break;              
            }
        }

        /// <summary>
        /// Update property binding 
        /// ToDo: Use Custom EventArg to pass data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Dealer_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "CardsInHand":
                    DealerCardsInHandChanged();
                    break;
                case "TotalHandValue":
                    DealerTotalHandValueChanged();
                    break;
                case "DownCardShowFace":                    
                    DealerDownCardShowFace();
                    break;
                case "DownCardShowBack":                    
                    DealerDownCardShowBack();
                    break;
                case "DiscardDownCard":                    
                    DealerDownCardRemoveChanged();
                    break;
            }
        }
        #endregion

        #region Update bound GUI Controls

        private void GameResultsUpdated()
        {
            HandStatus = _bjgDataContext.GetGameResults();
        }

        private void PlayerCardsInHandChanged()
        {
            //Update binding from model
            PlayerHandImages.Clear();
            foreach (Card c in _bjgDataContext.GetPlayerCardsInHand())
            {
                PlayerHandImages.Add(c.Image);
            }
        }

        private void PlayerCashChanged()
        {
            PlayerCash = _bjgDataContext.GetPlayerCash();
        }

        private void PlayerCurrentBetChanged()
        {
            CurrentBet = _bjgDataContext.GetPlayerCurrentBet();
        }

        private void PlayerTotalHandValueChanged()
        {
            PlayerTotalPoints = _bjgDataContext.GetPlayerTotalHandValue();
        }


        private void DealerCardsInHandChanged()
        {
            DealerHandImages.Clear();
            foreach (Card c in _bjgDataContext.GetDealerCardsInHand())
            {
                DealerHandImages.Add(c.Image);
            }
        }

        private void DealerTotalHandValueChanged()
        {
            DealerTotalPoints = _bjgDataContext.GetDealerTotalHandValue().ToString();
        }

        private void DealerDownCardShowFace()
        {
            DealerHandDownCard.Clear();
            _dealerHandDownCard.Add(_bjgDataContext.GetDealerDownCardImage());
        }

        private void DealerDownCardShowBack()
        {
            DealerHandDownCard.Clear();
            _dealerHandDownCard.Add(_bjgDataContext.GetCardBackImage());
        }

        private void DealerDownCardRemoveChanged()
        {
            DealerHandDownCard.Clear();           
        }
        #endregion

    }
}
