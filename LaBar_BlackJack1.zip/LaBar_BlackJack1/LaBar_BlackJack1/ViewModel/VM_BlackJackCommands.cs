﻿// VM_BlackJackCommands.cs 
// ICommands used to handle user actions from the View
// 
// 3/3/2019 initial creation - PJL

using System.ComponentModel;
using System.Media;

namespace LaBar_BlackJack1.ViewModel
{
    public partial class VM_BlackJack : INotifyPropertyChanged
    {
        public BlackJackICommand NextHandCommand { get; set; }
        public BlackJackICommand PlaceBetCommand { get; set; }
        public BlackJackICommand DealCommand { get; set; }
        public BlackJackICommand HitCommand { get; set; }
        public BlackJackICommand StandCommand { get; set; }
        public BlackJackICommand NewGameCommand { get; set; }
        public BlackJackICommand QuitCommand { get; set; }
        public BlackJackICommand RulesCommand { get; set; }


        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Start New Game
        /// </summary>
        private void OnNewGame()
        {
            SystemSounds.Beep.Play();
            _bjgDataContext.InitNewGame();
            CurrentGameState = GameState.WaitingInitialBet;            
        }

        private bool CanNewGame()
        {
            return _gameState == GameState.NoGame ? true : false ;
        }

        
        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// User has placed a bet
        /// </summary>
        private void OnPlaceBet()
        {
            _bjgDataContext.UpdatePlayerBet(); 
            CurrentGameState = GameState.BetOrDeal;
        }

        private bool CanPlaceBet()
        {
            if ( ( _gameState == GameState.WaitingInitialBet || _gameState == GameState.BetOrDeal) &&
                  _bjgDataContext.PlayerHasChips())
            {
                return true;
            }

            return false;           
        }       

        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Deal The Cards
        /// </summary>
        private void OnDeal()
        {
            _bjgDataContext.DealInitialCards();
            DealerTotalPoints = "???";
            if(_bjgDataContext.CheckForBlackJack())
            {
                DealerDownCardShowFace();
                DealerTotalHandValueChanged();
                CurrentGameState = GameState.NextHand;
            }
            else
            {
                CurrentGameState = GameState.HitOrStand;
            }
        }

        private bool CanDeal()
        {
            return _gameState == GameState.BetOrDeal ? true : false;
        }


        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Player wants a Hit
        /// </summary>
        private void OnHit()
        {
            _bjgDataContext.PlayerHit();
            CurrentGameState = _bjgDataContext.CheckForPlayerBust() ? GameState.NextHand : GameState.HitOrStand;
        }

        private bool CanHit()
        {
            return _gameState == GameState.HitOrStand ? true : false;
        }
             
        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Delaers Turn
        /// </summary>
        private void OnStand()
        {
            DealerDownCardShowFace();
            _bjgDataContext.ProcessDealerTurn();
            DealerTotalHandValueChanged();
            CurrentGameState = GameState.NextHand;           
        }

        private bool CanStand()
        {
            return _gameState == GameState.HitOrStand ? true : false;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Start a new hand
        /// </summary>
        private void OnNextHand()
        {
            _bjgDataContext.StartNextHand();
            DealerTotalPoints = "0";
            CurrentGameState = GameState.WaitingInitialBet;
        }

        private bool CanNextHand()
        {
            return _gameState == GameState.NextHand ? true : false;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Quit current game
        /// </summary>
        private void OnQuit()
        {
            DealerTotalPoints = "0";
            _bjgDataContext.AddNewHighScores();
            CurrentGameState = GameState.NoGame;           
        }

        private bool CanQuit()
        {
            return _gameState == GameState.WaitingInitialBet ? true : false;
        }


        private void OnRules()
        {
            ShowOrHideRules();
        }

        private bool CanRules()
        {
            return true;
        }       
    }
}
