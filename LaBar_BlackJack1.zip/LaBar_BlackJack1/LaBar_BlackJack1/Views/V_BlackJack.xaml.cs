﻿using System.Windows.Controls;

namespace LaBar_BlackJack1.Views
{
    /// <summary>
    /// Interaction logic for V_BlackJack.xaml
    /// </summary>
    public partial class V_BlackJack : UserControl
    {
        public V_BlackJack()
        {
            InitializeComponent();
        }
    }
}
