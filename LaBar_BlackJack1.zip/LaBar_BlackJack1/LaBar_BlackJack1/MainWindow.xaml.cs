﻿// Deck.cs 
// Use as the main table for BlackJack Game
//
// 3/3/2019 initial creation - PJL

using System.Windows;
using LaBar_BlackJack1.ViewModel;
using LaBar_BlackJack1.Services;

namespace LaBar_BlackJack1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();           
        }

        private void BlackJackViewControl_Loaded(object sender, RoutedEventArgs e)
        {
             VM_BlackJack blackJackViewModelObject =  new VM_BlackJack(new BlackJackGameDataService());

             BlackJackViewControl.DataContext = blackJackViewModelObject;
        }

    }
}
